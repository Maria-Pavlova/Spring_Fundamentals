package com.example.exam.models.enums;

public enum ConditionName {
    EXCELLENT, GOOD, ACCEPTABLE
}
